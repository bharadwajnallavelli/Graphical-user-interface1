/*                                                                                                                                                           
    Name: Bharadwaj Nallavelli                                                                                                                                       
    Contact: Bharadwaj_Nallavelli@student.uml.edu                                                                                                                     
    Major: Computer Science                                                                                                                                    
    School: University of Massachusetts Lowell                                                                                                                                                                                                                                                              Description: Assignment 6 - Creating an Interactive Dynamic Table
*/
// prevent other event handlers from executing after a certain event is fired.
// sorec took help from stackoverflow.
    jQuery(document).ready(function () 
        {
            multiplicationtable();
            $('form').on('submit', function (event) 
        { 
    event.preventDefault();
    multiplicationtable();
        });
        });
// Multiplication table function is created here.
    function multiplicationtable()
        {
// Whatever the values given in the html form the values are initialised to the variables declared using the name from the inputboxes.  
//Row starting value
            var rowSt = parseInt($('input[name=rowStart]').val()), 
//Row ending value
            rowEn = parseInt($('input[name=rowEnd]').val()), 
//Column start value
            colSt = parseInt($('input[name=colStart]').val()), 
//Column ending value
            colEn = parseInt($('input[name=colEnd]').val()); 
// For incrementing the column i declared as variable c.
            var c = colSt; 
// checking if the entered inputs are correct or wrong 
//If the startrow range is given smaller than Endrow range we get the alert as you need to input large number.    
            if (rowSt > rowEn) 
        {
            alert("You need to input a larger number in row ranges.!");
            return false;
        }
// If the entered range is not correct in column ranges we get the alert as you need to input larger number in column.
    if (colSt > colEn) 
        {
            alert("You need to input a larger number in column ranges!");
            return false;
        }
//Checking if the user have entered other than numbers the conditions are if they are empty boxes or they having other than numbers.
    if (rowSt === null || rowSt === "" ||
    rowEn === null || rowEn === "" ||
    colSt === null || colSt === "" ||
    colEn === null || colEn === "") {
    alert("You are missing a number in a field!");
    return false;
        }
//Check that the rows and column that the user inputted are actually numbers
    if (typeof rowSt === 'number' && typeof rowEn === 'number' && typeof colSt === 'number' && typeof colEn === 'number') 
        {
            var table = '<table>';
//Here i start making the colomns and rows
            table = '<tr>' + '<td></td>';
    for (var i = rowSt; i <= rowEn; i++) 
        {
            table += '<td>' + i + '</td>';
         }
    for (var j = colSt; j <= colEn; j++) 
        {
            table += '<tr>';
            table += '<td>' + c + '</td>';
            for (var k = rowSt; k <= rowEn; k++)
        {
            table += '<td>' + j * k + '</td>';
        }
            table += '</tr>';
//Increment the column number or else it won't change
             c++; 
        }
            table += '</table>';
            $('#table').html(table); 
        }
// If you enter other than numbers we get alert as entered something is not a number.
    else 
        {
            alert("You have entered something that is not a number.");
        }
        }
