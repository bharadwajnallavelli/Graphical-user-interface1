/*                                                                                                                                                          
        Name: Bharadwaj Nallavelli                                                                                                                                       
        Contact: Bharadwaj_Nallavelli@student.uml.edu                                                                                                                     
        Major: Computer Science                                                                                                                                    
        School: University of Massachusetts Lowell                                                                                                                                                                                                                                                                                 
        Description: Assignment 8- Creating an Interactive Dynamic Table using the slider and jquery.
        */
var indextab = 1;
// This function is used for auto submission for generating multiplication table.
// code structure for submission_auto took help from stackoverflow.
function submission_auto() {
  // If the form is valid
  if( $("form#multiplicationform").valid() == true ) {
    // Then make it submit, which should update the tab in the process.
    $("form#multiplicationform").submit();
  }
}
//    The savethetab() allows user to save the  the current multiplication table into a new tab.
 
function savethetab() {
  // total tabcount is made here because i made the code in the way that if it exceeds the count greater than 20 the new tabs are not going to save.
  var totaltabcount = $("#tabs li").length + 1;
  console.log("Current tab count is: " + totaltabcount);
// If the totaltab count is greater than 20 then warning arrives on the page.
  if(totaltabcount > 20) {
    alert("Sorry, only 20 multiplication tables may be saved at the same time. Please delete one to save another table.");
    return false;
  }

  // This should initialize the jQuery UI tabs.
  $( "#tabs" ).tabs();
 // I have decided to display the Tab title bar for each table as: 0 TO 50 (horizontal beginning to end) by 0 TO 50 (vertical beginning to end)
// The numbers entered in the form are derived by document.getElementById to use in js. For all the horizontal rows are columns are done here. 
 var start_horizontal = Number(document.getElementById('horizontalstart').value);
  var end_horizontal = Number(document.getElementById('horizontalend').value);
  var verticalstart = Number(document.getElementById('verticalstart').value);
  var verticalend = Number(document.getElementById('verticalend').value);
// Increment the index each time we add a new tab.
  indextab++;   
// Create the title bar, this will be a string to send to .append()
  var title = "<li class='tab'><a href='#tab-" + indextab + "'>" + "(" +start_horizontal +
              " to " + end_horizontal + ")" + " by " + "(" + verticalstart + " to " + verticalend + ")"+ "</a>" +
              "<span class='ui-icon ui-icon-close' role='presentation'></span>" + "</li>";

  // a new Title bar is added.
  $( "div#tabs ul" ).append( title );
	//  current multiplication table is added.
  $( "div#tabs" ).append('<div id="tab-' + indextab + '">' + $("#multiplication_table").html() + '</div>');
  $( "#tabs" ).tabs("refresh");
	// Make the new tab active, so that the user knows it updated.
  $( "#tabs" ).tabs("option", "active", -1);
   // Add a remove button, from jQuery UI's webpage manipulation of jquery ui.
  $( "#tabs" ).delegate( "span.ui-icon-close", "click", function() {
      var panelID = $( this ).closest( "li" ).remove().attr( "aria-controls" );
      $( "#" + panelID ).remove();
      // Using try / catch to prevent exceptions from appearing.
      try {
        $( "#tabs" ).tabs("refresh");
      }
      catch (e) {
      }
	  // If this is the last tab, let's reset the page to way it was before.
      if( $('div#tabs ul li.tab').length == 0) {
        try {
          $("#tabs").tabs("destroy");
        }
        catch (e) {
        }
		return false;   
      }
  });
}
// code for the slider is made here to appear for the functions.
function sliderfunction() {
  // Horizontal Start Slider
  $("#horizstart1").slider({
    //minimum and max value of the slider is -50 to 50.
	min: -50,
    max: 50,
    slide: function(event, ui) {
      $("#horizontalstart").val(ui.value);
	   // Call the auto submit function on slide.
      submission_auto(); 
    }
  });
  $("#horizontalstart").on("keyup", function() {
    $("#horizstart1").slider("value", this.value);
    submission_auto();  // Call the auto submit function on keyup as well.
  });

  // Horizontal End Slider
  $("#horizend1").slider({
	  //minimum and max value of the slider is -50 to 50.
    min: -50,
    max: 50,
    slide: function(event, ui) {
      $("#horizontalend").val(ui.value);
      submission_auto();  
    }
  });
  $("#horizontalend").on("keyup", function() {
    $("#horizend1").slider("value", this.value);
    submission_auto(); 
  });

  // vertical Start Slider
  $("#vertistart").slider({
	  //minimum and max value of the slider is -50 to 50.
    min: -50,
    max: 50,
    slide: function(event, ui) {
      $("#verticalstart").val(ui.value);
      submission_auto();  
    }
  });
  $("#verticalstart").on("keyup", function() {
    $("#vertistart").slider("value", this.value);
    submission_auto(); 
  });

  // vertical End Slider
  $("#vertiend").slider({
	  //minimum and max value of the slider is -50 to 50.
    min: -50,
    max: 50,
    slide: function(event, ui) {
      $("#verticalend").val(ui.value);
      submission_auto(); 
    }
  });
  $("#verticalend").on("keyup", function() {
    $("#vertiend").slider("value", this.value);
    submission_auto(); 
  });
}
// function validate() is done here and rules are defined here.
function validate() {
$("#multiplicationform").validate({
    // Rules for validating the form.
    rules: {
      horizontalstart: {
		  //The format of the input should be only number. and min and max is -50 to 50 and the fields are required.
        number: true,
        min: -50,
        max: 50,
        required: true
      },
      horizontalend: {
		  //The format of the input should be only number. and min and max is -50 to 50 and the fields are required.
        number: true,
        min: -50,
        max: 50,
        required: true
      },
      verticalstart: {
		  //The format of the input should be only number. and min and max is -50 to 50 and the fields are required.
        number: true,
        min: -50,
        max: 50,
        required: true
      },
      verticalend: {
		  //The format of the input should be only number. and min and max is -50 to 50 and the fields are required.
        number: true,
        min: -50,
        max: 50,
        required: true
      }
    },

    //Messages that should appear to the user when the user gives the input wrong.
	//Message should appear as ERROR: enter the valid number between -50 and 50 changing horizontal or vertical as the user gives input in the corresponding fields.
    messages: {
      horizontalstart: {
		  // Messages for the number, min, max, required are defined here.
        number: "ERROR:Please enter a valid number between -50 and 50 for the Horizontal start.",
        min: "ERROR:Please enter a valid number greater than or equal to -50 for the Horizontal start.",
        max: "ERROR:Please enter a valid number less than or equal to 50 for the Horizontal start.",
        required: "ERROR:A number between -50 and 50 is required for the Horizontal start."
      },
      horizontalend: {
		  // Messages for the number, min, max, required are defined here.
        number: "ERROR:Please enter a valid number between -50 and 50 for the Horizontal end.",
        min: "ERROR:Please enter a valid number greater than or equal to -50 for the Horizontal end.",
        max: "ERROR:Please enter a valid number less than or equal to 50 for the Horizontal end.",
        required: "ERROR:A number between -50 and 50 is required for the Horizontal end."
      },
      verticalstart: {
		  // Messages for the number, min, max, required are defined here.
        number: "ERROR:Please enter a valid number between -50 and 50 for the vertical start.",
        min: "ERROR:Please enter a valid number between -50 and 50 for the vertical start.",
        max: "ERROR:Please enter a valid number between -50 and 50 for the vertical start.",
        required: "ERROR:A number between -50 and 50 is required for the vertical start."
      },
      verticalend: {
		  // Messages for the number, min, max, required are defined here.
        number:"ERROR:Please enter a valid number between -50 and 50 for the vertical end.",
        min:"ERROR:Please enter a valid number between -50 and 50 for the vertical end.",
        max: "ERROR:Please enter a valid number between -50 and 50 for the vertical end.",
        required: "ERROR:A number between -50 and 50 is required for the vertical end."
      }
    },

    // This gets called when the form is submitted and valid.
    submitHandler: function() {
      multiplicationtable();
      return false;
    },
// Nothing should show up if the user gives the input in wrong.
    invalidHandler: function() {
      $("#warningmessage").empty();
      $("#multiplication_table").empty();
    },
// The below code is used to place the error message.
    errorElement: "div",
    errorPlacement: function(error, element) {
      error.insertAfter(element);
    },
	onkeyup: function( element, event ) {
      // Call the auto submit function on keyup.
      submission_auto();
    }
  });
}
// This function calculates the multiplication table.
function multiplicationtable() {
	// Elements from the form is linked here by using document.getElementById method.
  var start_horizontal = Number(document.getElementById('horizontalstart').value);
  var end_horizontal = Number(document.getElementById('horizontalend').value);
  var verticalstart = Number(document.getElementById('verticalstart').value);
  var verticalend = Number(document.getElementById('verticalend').value);
  $("#warningmessage").empty();
 // Swap beginning / ending numbers if the start is larger than the beginning.
  if (start_horizontal > end_horizontal) {
    $("#warningmessage").append("<p class='warning_class'>Horizontal start and horizontal end is swapped.</p>");
     var temporarynumber = start_horizontal;
    start_horizontal = end_horizontal;
    end_horizontal = temporarynumber;
  }
  if (verticalstart > verticalend) {
    $("#warningmessage").append("<p class='warning_class'>vertical start and vertical end is swapped.</p>");
var temporarynumber = verticalstart;
    verticalstart = verticalend;
    verticalend = temporarynumber;
  }
  var matrix = {};

  //calculating  how many rows and columns we have.
  var rows = Math.abs(end_horizontal - start_horizontal);
  var columns = Math.abs(verticalend - verticalstart);

  // Indexes for the 2D array.
  var horz = start_horizontal;
  var vertical1 = verticalstart;
  for (var x = 0; x <= columns; x++) {
    var tmp_arr = [];

    for (var y = 0; y <= rows; y++) {
      // Calculate the given spot in the multiplication table.
      var calc = horz * vertical1;
      tmp_arr[y] = calc;
      horz++;
    }

    // Save the current row in the object.
    matrix["row" + x] = tmp_arr;
	horz = start_horizontal;       
    vertical1++;
  }
  var content = "";
// Opening table tags.
  content += "<table>";
// First row, and put an empty spot in the top left corner.
  content += "<tr><td></td>";
  for (var a = start_horizontal; a <= end_horizontal; a++) {
    content += "<td>" + a + "</td>";
  }
  content += "</tr>";
  var vertical1 = verticalstart;

  // Fill in each row after the first.
  for (var x = 0; x <= columns; x++) {
    // Set the left most column first.
    content += "<tr><td>" + vertical1 + "</td>";

    // Add in all the multiplication for this row.
    for (var y = 0; y <= rows; y++) {
      content += "<td>" + matrix["row" + x][y] + "</td>";
    }
    vertical1++;

    // Close each row.
    content += "</tr>";
  }

  // Ending table tags.
  content += "</table>";

  // Now the content gets loaded into the HTML page.
  $("#multiplication_table").html(content);

  // Stop the form from refreshing.
  return false;
}