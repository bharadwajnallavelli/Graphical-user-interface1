/*                                                                                                                                                           
        Name: Bharadwaj Nallavelli                                                                                                                                       
        Contact: Bharadwaj_Nallavelli@student.uml.edu                                                                                                                     
        Major: Computer Science                                                                                                                                    
        School: University of Massachusetts Lowell                                                                                                                                                                                                                                                                                 
        Description: Assignment 9 
		This assignment is about making the scrabble board game using jquery and Html css. 
        For this javascript i took the help from links provided in piazza*/
/* document will be loaded when ready function is made */
$(document).ready(function() {
	/*generate random using function randomgenerator */
	var randomgenerator = function(){
		//error check 
		if ( tilesofletters.length == 0 ){
			// alert is made when error occurs
			alert("error");
		} else {	
			numberoftiles--;
			var index = Math.floor(Math.random() * tilesofletters.length);		
			return index;
		}
	}
	/* helperhand code which will produce random tiles*/
	var helperhand = function(randLetterTile){
		player1.push(randLetterTile);
	}
	/*helper array that will delete from*/
	var delhelper = function(index, arrayToDeleteFrom){
		arrayToDeleteFrom.splice(index, 1);
	}

	/*Delete the current 7 tiles on the tilesrack*/
	var delhand = function(){
		for ( var temp = 0 ; temp < 7 ; temp++ ){
			delhelper(0, player1);
		}	
	}

	/*Create 7 new tiles onto the tilesrack*/
	var newHand = function(){
		for ( var temp = 0 ; temp < 7 ; temp++ ){
			var index = randomgenerator();
			helperhand(tilesofletters[index]);
			tilesofletters.splice(index, 1);
		}
	}
	/*Create the whole scrabble board*/
	var createtable = function(){

		var board1;
		var temprow;
		var rowGreaterThanSeven = false;

		board1 = "<table id=scrabbleBoardTable>";
		//Creating each row starting having 9 rows
		for ( var row = 3 ; row < 12 ; row++ ) {
			board1 += "<tr id=row" + row + ">";
		//creating each col having 9 col
			for ( var col = 3 ; col < 12 ; col++ ) {
				temprow = row;
				if (row > 6){
					rowGreaterThanSeven = true;
					temprow = row;
					row = 14 - row;
				}
	//Creating each cell in a row and col
	switch(row) {
	// cases are made here for case 0
	case 0:
	switch(col) {
	// for case 3
	case 3:
	board1 += "<td id=row" + temprow + "col" + col + " class='ui-droppable doubleLetter'></td>";
	break;
	//for case 11
	case 11:
	board1 += "<td id=row" + temprow + "col" + col + " class='ui-droppable doubleLetter'></td>";
	break;
	//default is made here
	default:
	board1 += "<td id=row" + temprow + "col" + col + " class='ui-droppable normalTile'></td>";
	break;
	}
	break;
	//for case 1
	case 1:
	switch(col) {
    case 5:
	board1 += "<td id=row" + temprow + "col" + col + " class='ui-droppable tripleLetter'></td>";
	break;
	case 9:
	board1 += "<td id=row" + temprow + "col" + col + " class='ui-droppable tripleLetter'></td>";
	break;
	//default case is
	default:
	board1 += "<td id=row" + temprow + "col" + col + " class='ui-droppable normalTile'></td>";
	break;
	}
	break;
	case 2:
	switch(col) {
	case 6:
	board1 += "<td id=row" + temprow + "col" + col + " class='ui-droppable doubleLetter'></td>";
	break;
	case 8:
	board1 += "<td id=row" + temprow + "col" + col + " class='ui-droppable doubleLetter'></td>";
	break;
	case 12:
	board1 += "<td id=row" + temprow + "col" + col + " class='ui-droppable doubleWord'></td>";
	break;
	default:
	board1 += "<td id=row" + temprow + "col" + col + " class='ui-droppable normalTile'></td>";
	break;
	}
	break;
	case 3:
	switch(col) {
	//case 3 is made here						
	case 3:
	board1 += "<td id=row" + temprow + "col" + col + " class='ui-droppable doubleWord'></td>";	
	break;
	case 7:
	board1 += "<td id=row" + temprow + "col" + col + " class='ui-droppable doubleLetter'></td>";
	break;
	case 11:
	board1 += "<td id=row" + temprow + "col" + col + " class='ui-droppable doubleWord'></td>";
	break;
	//default is made here						
	default:
    board1 += "<td id=row" + temprow + "col" + col + " class='ui-droppable normalTile'></td>";
	break;
	}
	break;
	case 4:
	switch(col) {
	case 4:
	board1 += "<td id=row" + temprow + "col" + col + " class='ui-droppable doubleWord'></td>";	
	break;
	case 10:
	board1 += "<td id=row" + temprow + "col" + col + " class='ui-droppable doubleWord'></td>";
	break;
	default:
	board1 += "<td id=row" + temprow + "col" + col + " class='ui-droppable normalTile'></td>";
	break;	
	}
	break;
	case 5:
	switch(col) {
	//col is switched						
	case 5:
	board1 += "<td id=row" + temprow + "col" + col + " class='ui-droppable tripleLetter'></td>";	
	break;
	case 9:
	board1 += "<td id=row" + temprow + "col" + col + " class='ui-droppable tripleLetter'></td>";
	break;
	case 13:
	board1 += "<td id=row" + temprow + "col" + col + " class='ui-droppable tripleLetter'></td>";
	break;
	default:
	board1 += "<td id=row" + temprow + "col" + col + " class='ui-droppable normalTile'></td>";
	break;
	}
	break;
	case 6:
    switch(col) {
	case 6:
	board1 += "<td id=row" + temprow + "col" + col + " class='ui-droppable doubleLetter'></td>";	
	break;
	case 8:
	board1 += "<td id=row" + temprow + "col" + col + " class='ui-droppable doubleLetter'></td>";
	break;
	case 12:
	board1 += "<td id=row" + temprow + "col" + col + " class='ui-droppable doubleLetter'></td>";
	break;
	default:
	board1 += "<td id=row" + temprow + "col" + col + " class='ui-droppable normalTile'></td>";
	break;
	}
	break;
	case 7:
	switch(col) {
	case 3:
	board1 += "<td id=row" + temprow + "col" + col + " class='ui-droppable doubleLetter'></td>";	
	break;
	case 7:
	board1 += "<td id=row" + temprow + "col" + col + " class='ui-droppable middleStarTile'></td>";	
	break;
	case 11:
	board1 += "<td id=row" + temprow + "col" + col + " class='ui-droppable doubleLetter'></td>";
	break;
	default:
	board1 += "<td id=row" + temprow + "col" + col + " class='ui-droppable normalTile'></td>";
	break;
	}
	break;
	default:
	break;
	}
	// if condition is if row greater than seven
	if ( rowGreaterThanSeven ) {
	// row is temp row
	row = temprow;
	}
	}
	board1 += "</tr>";
	}
	board1 += "</table>";
	$('#board1').html(board1);
	}
    //variables created 
	//for number of tiles
	var numberoftiles = 0;
	//an array for tiles of letters
	var tilesofletters = [];
	//the tiles in the player1 hand
	var player1 = [];
	//the tiles that the player has played on the board but not submit
	var storethetile = [];
	//the score that the player has right now
	var scoreoftheplayer = 0;
	//a map that contains each letter and its value
	var tableofletters = {};
	//starting left position for each player's tiles
	var leftplayertiles = {};
	//starting top position for each player's tiles	
	var topplayertiles = {};
	//stored player store
	var obtainedscore = 0 ;
	//mulitplier
	var multiplier = 1;
	//value of each word
	var valueoftheword = 0 ;
	//value of the word tiles
	var tilevalueword = 0;
	//Map of remaining tiles
	var remainingtiles = {};
	//a string that contains the word on the board
	var wordsboard = "";
 /*generate the 7 new tiles for player and add to the tilesrack*/
	var createTiles = function(){
		var individualTiles = "" ;
		var position = $('#tilesrack').position();
		var leftposition;
//creating each tile for the user
		for ( var x = 0 ; x < player1.length ; x++ ) {
//remaining tiles
		remainingtiles[player1[x]]--;
		$('#letter'+player1[x]).html(player1[x] + ": " + remainingtiles[player1[x]]);
        individualTiles = "<img id='tile" + x +"' class='"  + player1[x] + " tilePiece draggable ui-draggable ui-draggable-handle' src='images/scrabble/ScrabbleTiles/" + player1[x] + ".jpg'> ";  
		leftposition = position.left + 22 + (52 * x);
		topPos = position.top + 30;
		leftplayertiles["tile"+x] = leftposition;
		topplayertiles["tile"+x] = topPos;
		$('#scrabbleTiles').append(individualTiles);
		$('#tile'+x).css("left", leftposition).css("top", topPos).css("position", "absolute");
		//implementing draggable for each tile on th rack
		//dragable code from documentation of js
		$('#tile'+x).draggable({
		appendTo: scrabbleBoardTable,
		revert: 'invalid',
		start: function(ev, ui) {
	    // Save original position. (used for swapping tiles)
	    var startposition = ui.helper.position();
	    var letterOfTile = (ui.helper)[0].className.split(" ", 1);
		//if condition for making the dragable tile and making score
	    if ( ($('#'+(ui.helper)[0].id).parent())[0].id !== "scrabbleTiles" ){
	    var valueOfTile = (($('#'+(ui.helper)[0].id).parent())[0]).className.split(" ", 2)[1];
	    updateScore(valueOfTile,"sub", tableofletters[letterOfTile]);	
	    }
	     },
	     stop: function(ev, ui) {
 // If an invalid event is found, this will return the draggable object to its
// default "invalid" option. From this Stackoverflow post (also used in the droppable part.)
$(this).draggable('option','revert','invalid');
console.log(($('#'+(ui.helper)[0].id).parent())[0].id);
var letterOfTile = (ui.helper)[0].className.split(" ", 1);
if ( ($('#'+(ui.helper)[0].id).parent())[0].id === "scrabbleTiles" ){
wordsboard = wordsboard.replace((ui.helper)[0].className.split(" ", 1), "");
$('#wordsboard').html("Word: " + wordsboard);
}
//else condition
	else {
wordsboard += (ui.helper)[0].className.split(" ", 1);
$('#wordsboard').html("Word: " + wordsboard);
var valueOfTile = (($('#'+(ui.helper)[0].id).parent())[0]).className.split(" ", 2)[1];
//updating the score value when a tile is dragged
updateScore(valueOfTile, "add", tableofletters[letterOfTile]);  
}
},
//containment made at gamebody
containment: '#gamebody',
snap: ".ui-droppable",
snapMode: 'inner',
cursor: "move",
cursorAt: { top: 25, left: 25 }
			});
		}
		
	}

	//return the amount of bonus to multiply the word with
	var getTripleDoubleWord = function() {
		return multiplier;
	}

	//set the amount of bonus to multiply the word with
	var setTripleDoubleWord = function( multi ) {
		multiplier = multi;
	}

	/*initialize the array with all the number of tiles*/
	var init = function(){
var tilecharacter;
var tile;
var tileremaintable;
	var numOfLetterRead = 0;
var tilerow1 = "<tr id='remainingTableRow1'>";
var tilerow2 = "<tr id='remainingTableRow2'>";
var tilerow3 = "<tr id='remainingTableRow3'>";
//putting each letter into array and set up remaining table
for (var i = 0; i < Object.keys( ScrabbleTiles ).length  + 1; i++){
if ( i < Object.keys( ScrabbleTiles ).length - 1 ){
tilecharacter = String.fromCharCode( 65 + i );
tableofletters[tilecharacter] = ScrabbleTiles[tilecharacter].value;
} else if ( i < Object.keys( ScrabbleTiles ).length ) {
tilecharacter = "_";
} else {
tilecharacter = "Total";
}
if ( tilecharacter != "Total" ){
for ( var x = 0 ; x < ScrabbleTiles[tilecharacter]["original-distribution"]; x++ ){
	tilesofletters[numberoftiles] = tilecharacter;
	//incrementing the number of tiles 
	numberoftiles++;
	}	
// number of tiles remaining based on use	
	var individualRowCol = "<td id='letter" + tilecharacter + "'>" + tilecharacter + ": " + ScrabbleTiles[tilecharacter]["original-distribution"] + "</td>";
	remainingtiles[tilecharacter] = ScrabbleTiles[tilecharacter]["number-remaining"];
	if ( numOfLetterRead < 9 ) {
	tilerow1+=individualRowCol;
	} else if ( numOfLetterRead >= 9 && numOfLetterRead < 18 ) {
	tilerow2+=individualRowCol;
	} else {
	tilerow3+=individualRowCol;
	}
			}
	//incrementing numOfLetterRead
			numOfLetterRead++;
		}
tilerow1 += "</tr>";
tilerow2 += "</tr>";
tilerow3 += "</tr>";
//tiles remained in table aapended with titlerow1,2,3
	$('#tileremaintable').append(tilerow1);
	$('#tileremaintable').append(tilerow2);
	$('#tileremaintable').append(tilerow3);
$('#scorebo').html("Score: " + scoreoftheplayer);
$('#wordsboard').html("Word: " + wordsboard);
	}
	/*update the player's score based on the tiles used on the board*/
	var updateScore = function(tileValue, operator, tileScore) {
var tile;
//checking the score for multiplier
		if (tileValue === "doubleLetter"){
			tile = 2;
		} else if (tileValue === "tripleLetter"){
			tile = 3;
		} else {
			tile = 1;
		}

if ( operator === "sub" ){
	if ( tileValue.indexOf("Letter") !== -1 ){
				tilevalueword-=(tile * tileScore);
	} else if ( tileValue.indexOf("Word") !== -1 ){
	tilevalueword-=tileScore;
	if ( tileValue === "tripleWord" ){
		setTripleDoubleWord(getTripleDoubleWord()/3);
	} else {
	setTripleDoubleWord(getTripleDoubleWord()/2);
				}
} else {
	tilevalueword-=tileScore;
			}
//value of the word if the word is made on special tiles
			valueoftheword = tilevalueword * getTripleDoubleWord();
		} else if( operator === "add" ){
	if ( tileValue.indexOf("Letter") !== -1 ){
				tilevalueword += tileScore * tile;
} else if ( tileValue.indexOf("Word") !== -1 ){
				tilevalueword += tileScore;
	if ( tileValue === "tripleWord" ){
	setTripleDoubleWord(getTripleDoubleWord() * 3);
				} else {
setTripleDoubleWord(getTripleDoubleWord() * 2);
				}
console.log("HEREEEEEE " + getTripleDoubleWord());
			} else {
				tilevalueword += tileScore;
			}
			valueoftheword = tilevalueword * getTripleDoubleWord();
		} else {
		}
		//update score
		$('#scorebo').html("Score: " + (obtainedscore + valueoftheword));

	}

	/*event listener for the click on reset button to delete current tiles and get new one*/
	document.getElementById("rstbtn").addEventListener("click", function(){
    	for ( var i = 0 ; i < player1.length ; i++ ) {
    		$('#tile'+i).remove();    		
    	}
    	$('#scorebo').html("Score: " + obtainedscore);
    	delhand();
    	newHand();
		createTiles();
		setTripleDoubleWord(1);
		valueoftheword = 0; 
		tilevalueword = 0;
		wordsboard = "";
		$('#wordsboard').html("Word: " + wordsboard);
	});

	/*event listener for the click on submit button to submit the words on the scrabble board*/
	document.getElementById("subbtn").addEventListener("click", function(){
		var countOfTileOnBoard = 0;
		for ( var i = 0 ; i < 7 ; i++ ) {
			if ( ($('#tile'+i).parent())[0].id !== "scrabbleTiles" ) {
				//console.log("Parent: " + ($('#tile'+i).parent()));
				($('#tile'+i).parent()).droppable("disable");
				$('#tile'+i).draggable("disable");
				player1.splice(i-countOfTileOnBoard, 1);
				countOfTileOnBoard++;
				storethetile.push(($('#tile'+i).parent())[0].id + "store");
				($('#tile'+i))[0].id = ($('#tile'+i).parent())[0].id + "store";
				//console.log(($('#tile'+i))[0].id);
			} else {
				remainingtiles[player1[i-countOfTileOnBoard]]++;
				//console.log(player1[i-countOfTileOnBoard]);
				$('#tile'+i).remove();
			}
		}
		var oldPlayerHandLength = player1.length;

		console.log(oldPlayerHandLength);
		//console.log("player1 size " + player1.length);
		for ( var i = 0 ; i < 7 - oldPlayerHandLength ; i++ ){
			//console.log("In here");
			var temp = randomgenerator();
			helperhand(tilesofletters[temp]);
			tilesofletters.splice(temp, 1);
		}
		obtainedscore += valueoftheword;
		createTiles();
		setTripleDoubleWord(1);
		valueoftheword = 0; 
		tilevalueword = 0;
		//console.log(player1.length);
		wordsboard = "";
		$('#wordsboard').html("Word: " + wordsboard);		
	});

	/*event listener for the click on reset board button to reset scrabble board and score*/
	document.getElementById("rstbrdbtn").addEventListener("click", function(){
		
		wordsboard = "";
		$('#wordsboard').html("Word: " + wordsboard);

		for ( var temp = 0 ; temp < storethetile.length ; temp++ ){
			$('#'+storethetile[temp]).remove();
			console.log(storethetile[temp].substring(0, storethetile[temp].length - 5));
			var parentId = storethetile[temp].substring(0, storethetile[temp].length - 5);
			$('#'+parentId).droppable("enable");
		}
		for ( var i = 0 ; i < player1.length ; i++ ) {
    		$('#tile'+i).remove();
    	}
		storethetile.splice(0, storethetile.length);

	valueoftheword = 0;
	tilevalueword = 0;
	obtainedscore = 0;
	delhand();
	tilesofletters.splice(0, tilesofletters.length);
	numberoftiles = 0;
	for (var i = 0; i < Object.keys( ScrabbleTiles ).length  + 1; i++){
	if ( i < Object.keys( ScrabbleTiles ).length - 1 ){
	tilecharacter = String.fromCharCode( 65 + i );
	tableofletters[tilecharacter] = ScrabbleTiles[tilecharacter].value;
	} else if ( i < Object.keys( ScrabbleTiles ).length ) {
	tilecharacter = "_";
	} else {
	tilecharacter = "Total";
		}
	if ( tilecharacter != "Total" ){
	for ( var x = 0 ; x < ScrabbleTiles[tilecharacter]["original-distribution"]; x++ ){
	tilesofletters[numberoftiles] = tilecharacter;
	numberoftiles++;
				}			
	remainingtiles[tilecharacter] = ScrabbleTiles[tilecharacter]["number-remaining"];
			}
	$('#letter'+tilecharacter).html(tilecharacter + ": " + remainingtiles[tilecharacter]);
		}
	// checking with  consoles the tilesofletters and obtaining score and creating new tiles
		console.log("tilesofletters " + tilesofletters.length);
    	newHand();
		createTiles();
		setTripleDoubleWord(1);
		$('#scorebo').html("Score: " + obtainedscore);
	});

//set up each droppable
$(function() {
//set up the tilesrack droppable
$('#tiles1').droppable({
accept: ".ui-draggable",
appendTo: "body",
drop: function( event, ui ){
var tileLetter = (((($(ui)[0]).draggable)[0]).className).split(" ", 1);
$('#scrabbleTiles').append($(ui.draggable));
ui.draggable.css("top", topplayertiles[ui.draggable[0].id]);
ui.draggable.css("left", leftplayertiles[ui.draggable[0].id]);
ui.draggable.css("position", "absolute");
updateScore("sub", tableofletters[tileLetter]);
			}
		});

		//set up each scrabble board cell droppable
		$('td table tbody tr td').droppable({
accept: ".ui-draggable",
appendTo: "body",
drop: function( event, ui ) {
//positioing 
			var tileLetter = (((($(ui)[0]).draggable)[0]).className).split(" ", 1);
if( $(this).children().length != 0 ) {	 										
 $(this).children().css("top", topplayertiles[$(this).children().first()[0].id]);
 $(this).children().css("left", leftplayertiles[$(this).children().first()[0].id]);
 $(this).children().css("position", "absolute") ;
 updateScore(($(this).context.className).split(" ", 2)[1], "sub", tableofletters[($(this).children().first()[0].className).split(" ", 1)]);
 $('#scrabbleTiles').append($(this).children());
 //append the ui dragable
 $(this).append($(ui.draggable));
ui.draggable.css("top", $(this).css("top"));
ui.draggable.css("left", $(this).css("left"));
ui.draggable.css("position", "relative");
//else condition for ui draggable
 } else {
$(this).append($(ui.draggable));
ui.draggable.css("top", $(this).css("top"));
ui.draggable.css("left", $(this).css("left"));
ui.draggable.css("position", "relative");
				}				
			}
		});
	});
	
	//starting the game
	createtable();
	init();
	newHand();
	createTiles();
});