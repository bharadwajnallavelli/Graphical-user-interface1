/*                                                                                                                                                           
        Name: Bharadwaj Nallavelli                                                                                                                                       
        Contact: Bharadwaj_Nallavelli@student.uml.edu                                                                                                                     
        Major: Computer Science                                                                                                                                    
        School: University of Massachusetts Lowell                                                                                                                                                                                                                                                                                 
        Description: Assignment 7 - Creating an Interactive Dynamic Table using jquery 
        */
$().ready(function () {
    // Checks if Max is greater than min. If it is, if it gives an error
    $.validator.addMethod("greaterThan",
            function (value, element, param) {
                var $min = $(param);
                if (this.settings.onfocusout) {
                    $min.off(".validate-greaterThan").on("blur.validate-greaterThan", function () {
                        $(element).valid();
                    });
                }
                return parseInt(value) > parseInt($min.val());
            }, "Max range must be greater than min range");
    // The form which is done in html multiplicationtable validation is done here and the rules and the messages which to prompt is done here. 
    multiplicationtable();
    $('#multiplicationtable').validate({
        // rules are done here for the input boxes 
        rules: {
            // checking whether the given input is a number or not and the range is -500 to 500 
            startrow1: {
                required: true,
                number: true,
                range: [-500, 500]
            },
             // checking whether the given input is a number or not and the range is -500 to 500 
            endrow1: {
                required: true,
                number: true,
                greaterThan: '#startrow1',
                range: [-500, 500]
            },
             // checking whether the given input is a number or not and the range is -500 to 500 
            columnstart1: {
                required: true,
                number: true,
                range: [-500, 500]
            },
             // checking whether the given input is a number or not and the range is -500 to 500 
            columnend1: {
                required: true,
                number: true,
                greaterThan: '#columnstart1',
                range: [-500, 500]
            }
        },
        // messages for the errors are declared here if the inputs in the boxes are given other than number it will raise an error as please enter the valid number in the box.
        messages: {
            startrow1: {
                required: "Required: Please enter a valid number in the box"
            },
            endrow1: {
                required: "Required: Please enter a valid number in the box"
            },
            columnstart1: {
                required: "Required: Please enter a valid number in  the box"
            },
            columnend1: {
                required: "Required: Please enter a valid number in the box"
            }
        }
    });
    /* Prevents form from submitting if there is an error */
    $('#multiplicationtable').on('submit', function (e) {
        e.preventDefault();
        var status = $('#multiplicationtable').validate({
            // These rules are made to stop from submitting form .
            rules: {
                 // checking whether the given input is a number or not and the range is -500 to 500 
                startrow1: {
                    required: true,
                    number: true,
                    range: [-50, 50]
                },
                 // checking whether the given input is a number or not and the range is -500 to 500 
                endrow1: {
                    required: true,
                    number: true,
                    greaterThan: '#startrow1',
                    range: [-50, 50]
                },
                columnstart1: {
                    required: true,
                    number: true,
                    range: [-50, 50]
                },
                columnend1: {
                    required: true,
                    number: true,
                    greaterThan: '#columnstart1',
                    range: [-50, 50]
                }
            },
            // messages are declared here .
            messages: {
                startrow1: {
                    required: "Required: Please enter a valid number in the box"
                },
                endrow1: {
                    required: "Required: Please enter a valid number in the box"
                },
                columnstart1: {
                    required: "Required: Please enter a valid number in the box"
                },
                columnend1: {
                    required: "Required: Please enter a valid number in the box"
                }
            }
        });
        status = status.currentForm;

        /* Check for error and focus on if there is one */
        if (status[0].inVal !== 'error' && status[1].className !== 'error' && status[2].inVal !== 'error' && status[3].inVal !== 'error') {
            multiplicationtable();
        } else {
            if (status[0].inVal === 'error') {
                document.getElementById("startrow1").focus();
            }
            if (status[1].inVal === 'error') {
                document.getElementById("endrow1").focus();
            }
            if (status[2].inVal === 'error') {
                document.getElementById("columnstart1").focus();
            }
            if (status[3].inVal === 'error') {
                document.getElementById("columnend1").focus();
            }
        }
    });
});
// Multiplication table function is created here.
function multiplicationtable() {
// Whatever the values given in the html form the values are initialised to the variables declared using the name from the inputboxes.  
//Row starting value
    var startrow1 = parseInt($('input[name=startrow1]').val()), 
     //Row ending value
            endrow1 = parseInt($('input[name=endrow1]').val()), 
            //Column starting value
            columnstart1 = parseInt($('input[name=columnstart1]').val()), 
            //Column ending value
            columnend1 = parseInt($('input[name=columnend1]').val()); //Column ending value
    //To increment the column.
    var c = columnstart1;

    //Check that the rows and column that the user inputted are actually numbers
    if (typeof startrow1 === 'number' && typeof endrow1 === 'number' && typeof columnstart1 === 'number' && typeof columnend1 === 'number') {
        var table = '<table>';

        //start making the colomns and rows
        table = '<tr>' + '<td></td>';
        for (var i = startrow1; i <= endrow1; i++) {
            table += '<td>' + i + '</td>';
        }
        for (var j = columnstart1; j <= columnend1; j++) {
            table += '<tr>';
            table += '<td>' + c + '</td>';
            for (var k = startrow1; k <= endrow1; k++) {
                table += '<td>' + j * k + '</td>';
            }
            table += '</tr>';
            //Increment the column number or else it won't change
            c++; 
        }
        table += '</table>';
        $('#table').html(table); 
    }
}

//Adds focus to the input boxes
$("input").focus(function () {
    $(this).next("span").css("display", "inline");
});